def solve(data):
    seen = set()
    result = []
    for record in data:
        raw_id = record.get('id', '')
        if not isinstance(raw_id, str):
            raw_id = str(raw_id)
        key = raw_id.strip().lower()
        if key not in seen:
            seen.add(key)
            result.append(record)
    return result