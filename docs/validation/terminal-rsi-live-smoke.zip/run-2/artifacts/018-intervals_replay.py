def solve(data):
    if not data:
        return []
    copied = []
    for item in data:
        copied.append([item[0], item[1]])
    copied.sort(key=lambda x: x[0])
    result = []
    result.append(copied[0])
    for i in range(1, len(copied)):
        cur = copied[i]
        last = result[-1]
        if cur[0] <= last[1] + 1:
            if cur[1] > last[1]:
                last[1] = cur[1]
        else:
            result.append(cur)
    return result