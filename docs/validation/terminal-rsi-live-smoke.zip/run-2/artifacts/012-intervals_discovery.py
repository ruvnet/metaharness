def solve(data):
    if not data:
        return []
    intervals = [[s, e] for s, e in data]
    intervals.sort(key=lambda x: x[0])
    merged = []
    for interval in intervals:
        if not merged:
            merged.append(interval)
        else:
            last = merged[-1]
            if interval[0] <= last[1] + 1:
                if interval[1] > last[1]:
                    last[1] = interval[1]
            else:
                merged.append(interval)
    return merged