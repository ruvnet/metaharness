def solve(data):
    if not data:
        return []
    
    # Filter out zero-length intervals and create a list of tuples
    # We do not mutate the input, we create new lists
    filtered = []
    for interval in data:
        start = interval[0]
        end = interval[1]
        if start < end:
            filtered.append([start, end])
    
    if not filtered:
        return []
    
    # Sort by start, then by end
    filtered.sort(key=lambda x: (x[0], x[1]))
    
    merged = []
    current_start = filtered[0][0]
    current_end = filtered[0][1]
    
    for i in range(1, len(filtered)):
        start = filtered[i][0]
        end = filtered[i][1]
        
        # Check if overlapping: strictly overlapping means start < current_end
        # If start == current_end, they only touch, so do not merge
        if start < current_end:
            # Merge: update current_end if end is larger
            if end > current_end:
                current_end = end
        else:
            # No overlap, push current interval to merged list
            merged.append([current_start, current_end])
            current_start = start
            current_end = end
    
    # Push the last interval
    merged.append([current_start, current_end])
    
    return merged