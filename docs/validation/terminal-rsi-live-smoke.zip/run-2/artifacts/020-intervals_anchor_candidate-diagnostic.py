def solve(data):
    if not data:
        return []
    copied = []
    for item in data:
        copied.append([item[0], item[1]])
    copied.sort(key=lambda x: x[0])
    result = []
    for interval in copied:
        if not result:
            result.append([interval[0], interval[1]])
        else:
            last = result[-1]
            if interval[0] <= last[1] + 1:
                if interval[1] > last[1]:
                    last[1] = interval[1]
            else:
                result.append([interval[0], interval[1]])
    return result