def solve(data):
    seen = set()
    result = []
    for item in data:
        key = item.strip().lower()
        if key not in seen:
            seen.add(key)
            result.append(item)
    return result