def solve(data):
    if not data:
        return []
    cleaned = []
    for item in data:
        if len(item) != 2:
            continue
        start = item[0]
        end = item[1]
        if start > end:
            continue
        if start == end:
            continue
        cleaned.append([start, end])
    if not cleaned:
        return []
    cleaned.sort(key=lambda x: x[0])
    result = [cleaned[0][:]]
    for i in range(1, len(cleaned)):
        cur = cleaned[i]
        last = result[-1]
        if cur[0] < last[1]:
            if cur[1] > last[1]:
                last[1] = cur[1]
        else:
            result.append(cur[:])
    return result