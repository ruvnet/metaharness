def solve(data):
    total = 0
    for s in data:
        if not isinstance(s, str):
            continue
        t = s.strip()
        if len(t) < 4:
            continue
        if t[1] != ':':
            continue
        m_part = t[0]
        ss_part = t[2:4]
        if len(ss_part) != 2:
            continue
        if not m_part.isdigit() or not m_part.isascii():
            continue
        if not ss_part.isdigit() or not ss_part.isascii():
            continue
        m_val = int(m_part)
        ss_val = int(ss_part)
        if ss_val > 59:
            continue
        total += m_val * 60 + ss_val
    return total