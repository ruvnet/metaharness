def solve(data):
    seen = set()
    result = []
    for s in data:
        key = s.strip().lower()
        if key not in seen:
            seen.add(key)
            result.append(s)
    return result