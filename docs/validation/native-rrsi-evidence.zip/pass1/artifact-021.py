def solve(data):
    total = 0
    for s in data:
        t = s.strip()
        if not t:
            continue
        parts = t.split(':')
        if len(parts) != 3:
            continue
        d_str, h_str, m_str = parts
        if not d_str.isdigit() or not d_str.isascii():
            continue
        if len(h_str) != 2 or not h_str.isdigit() or not h_str.isascii():
            continue
        if len(m_str) != 2 or not m_str.isdigit() or not m_str.isascii():
            continue
        h = int(h_str)
        m = int(m_str)
        if h > 23 or m > 59:
            continue
        d = int(d_str)
        total += d * 1440 + h * 60 + m
    return total