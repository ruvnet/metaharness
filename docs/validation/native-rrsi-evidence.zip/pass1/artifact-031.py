def solve(data):
    if not isinstance(data, str):
        return None
    s = data.strip()
    if len(s) == 0:
        return None
    i = 0
    sign = 1
    if s[0] == '+':
        i = 1
    elif s[0] == '-':
        sign = -1
        i = 1
    if i >= len(s):
        return None
    rest = s[i:]
    if len(rest) == 0:
        return None
    if '_' in rest:
        parts = rest.split('_')
        if len(parts) < 2:
            return None
        for p in parts:
            if len(p) == 0:
                return None
            if not p.isdigit():
                return None
            if not p.isascii():
                return None
        if len(parts[0]) < 1 or len(parts[0]) > 3:
            return None
        for p in parts[1:]:
            if len(p) != 3:
                return None
        cleaned = ''.join(parts)
    else:
        if not rest.isdigit():
            return None
        if not rest.isascii():
            return None
        cleaned = rest
    if len(cleaned) == 0:
        return None
    val = 0
    for ch in cleaned:
        val = val * 10 + (ord(ch) - 48)
    return sign * val