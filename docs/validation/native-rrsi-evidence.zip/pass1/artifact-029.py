def solve(data):
    total = 0
    for s in data:
        t = s.strip()
        if not t:
            continue
        parts = t.split(':')
        if len(parts) != 3:
            continue
        d_str, h_str, m_str = parts
        if not d_str.isdigit() or not d_str.isascii():
            continue
        if len(h_str) != 2 or not h_str.isdigit() or not h_str.isascii():
            continue
        if len(m_str) != 2 or not m_str.isdigit() or not m_str.isascii():
            continue
        h_val = int(h_str)
        m_val = int(m_str)
        if h_val < 0 or h_val > 23:
            continue
        if m_val < 0 or m_val > 59:
            continue
        d_val = int(d_str)
        total += d_val * 1440 + h_val * 60 + m_val
    return total