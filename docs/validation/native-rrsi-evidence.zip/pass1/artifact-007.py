def solve(data):
    nodes = set()
    edges = set()
    for e in data:
        if len(e) == 2:
            a, b = e
            nodes.add(a)
            nodes.add(b)
            edges.add((a, b))
    in_degree = {}
    adj = {}
    for n in nodes:
        in_degree[n] = 0
        adj[n] = []
    for a, b in edges:
        in_degree[b] = in_degree.get(b, 0) + 1
        adj[a].append(b)
    available = []
    for n in nodes:
        if in_degree[n] == 0:
            available.append(n)
    available.sort()
    result = []
    while available:
        node = available.pop(0)
        result.append(node)
        for nb in adj[node]:
            in_degree[nb] = in_degree.get(nb, 0) - 1
            if in_degree[nb] == 0:
                available.append(nb)
        available.sort()
    if len(result) == len(nodes):
        return result
    return []