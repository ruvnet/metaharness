def solve(data):
    nodes = data.get('nodes', [])
    edges = data.get('edges', [])
    priority = data.get('priority', {})
    if not nodes:
        return []
    node_set = set(nodes)
    in_degree = {}
    for n in nodes:
        in_degree[n] = 0
    adj = {}
    for n in nodes:
        adj[n] = []
    for e in edges:
        if len(e) != 2:
            continue
        u, v = e[0], e[1]
        if u in node_set and v in node_set:
            if v not in adj[u]:
                adj[u].append(v)
                in_degree[v] = in_degree.get(v, 0) + 1
    available = []
    for n in nodes:
        if in_degree[n] == 0:
            available.append(n)
    available.sort()
    result = []
    while available:
        best = None
        for n in available:
            if best is None:
                best = n
            else:
                p1 = priority.get(n, 0)
                p2 = priority.get(best, 0)
                if p1 < p2 or (p1 == p2 and n < best):
                    best = n
        result.append(best)
        for nxt in adj[best]:
            in_degree[nxt] = in_degree[nxt] - 1
            if in_degree[nxt] == 0:
                available.append(nxt)
        available.remove(best)
        available.sort()
    if len(result) != len(nodes):
        return []
    return result