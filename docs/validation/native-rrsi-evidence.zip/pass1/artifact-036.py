def solve(data):
    nodes = data.get('nodes', [])
    edges = data.get('edges', [])
    priority = data.get('priority', {})
    if not nodes:
        return []
    node_set = set(nodes)
    in_degree = {}
    for n in nodes:
        in_degree[n] = 0
    adj = {}
    for n in nodes:
        adj[n] = []
    for e in edges:
        if len(e) != 2:
            continue
        u, v = e
        if u in node_set and v in node_set:
            if v not in adj[u]:
                adj[u].append(v)
                in_degree[v] = in_degree.get(v, 0) + 1
    available = []
    for n in nodes:
        if in_degree[n] == 0:
            available.append(n)
    available.sort(key=lambda x: (priority.get(x, 0), x))
    result = []
    processed = 0
    while available:
        node = available.pop(0)
        result.append(node)
        processed += 1
        for neighbor in adj[node]:
            in_degree[neighbor] -= 1
            if in_degree[neighbor] == 0:
                available.append(neighbor)
        available.sort(key=lambda x: (priority.get(x, 0), x))
    if processed != len(nodes):
        return []
    return result