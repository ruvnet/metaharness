def solve(data):
    if not isinstance(data, str):
        return None
    s = data.strip()
    if len(s) == 0:
        return None
    sign = 1
    i = 0
    if s[0] == '+':
        i = 1
    elif s[0] == '-':
        sign = -1
        i = 1
    if i >= len(s):
        return None
    body = s[i:]
    if len(body) == 0:
        return None
    if '_' in body:
        parts = body.split('_')
        if len(parts) < 2:
            return None
        for idx, part in enumerate(parts):
            if len(part) == 0:
                return None
            if not part.isdigit() or not part.isascii():
                return None
            if idx == 0:
                if len(part) < 1 or len(part) > 3:
                    return None
            else:
                if len(part) != 3:
                    return None
        cleaned = ''.join(parts)
    else:
        if not body.isdigit() or not body.isascii():
            return None
        cleaned = body
    if len(cleaned) == 0:
        return None
    val = 0
    for ch in cleaned:
        val = val * 10 + (ord(ch) - 48)
    return sign * val