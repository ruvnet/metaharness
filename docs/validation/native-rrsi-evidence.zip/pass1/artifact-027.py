def solve(data):
    nodes = data.get('nodes', [])
    edges = data.get('edges', [])
    priority = data.get('priority', {})
    if not nodes:
        return []
    node_set = set(nodes)
    in_degree = {}
    adj = {}
    for n in nodes:
        in_degree[n] = 0
        adj[n] = []
    for e in edges:
        if len(e) != 2:
            continue
        u, v = e[0], e[1]
        if u in node_set and v in node_set:
            if v not in adj[u]:
                adj[u].append(v)
                in_degree[v] = in_degree[v] + 1
    available = []
    for n in nodes:
        if in_degree[n] == 0:
            available.append(n)
    available.sort()
    result = []
    processed = 0
    while available:
        best = available[0]
        for i in range(1, len(available)):
            a = available[i]
            pa = priority.get(best, 0)
            pb = priority.get(a, 0)
            if pb < pa or (pb == pa and a < best):
                best = a
        result.append(best)
        processed = processed + 1
        available.remove(best)
        for v in adj[best]:
            in_degree[v] = in_degree[v] - 1
            if in_degree[v] == 0:
                available.append(v)
        available.sort()
    if processed != len(nodes):
        return []
    return result