def solve(data):
    if not isinstance(data, str):
        return None
    s = data.strip()
    if not s:
        return None
    i = 0
    sign = 1
    if s[0] == '+':
        i = 1
    elif s[0] == '-':
        sign = -1
        i = 1
    if i >= len(s):
        return None
    body = s[i:]
    if not body:
        return None
    if '_' in body:
        parts = body.split('_')
        if len(parts) < 2:
            return None
        for p in parts:
            if not p:
                return None
            if not p.isdigit() or not p.isascii():
                return None
        first = parts[0]
        if len(first) < 1 or len(first) > 3:
            return None
        for p in parts[1:]:
            if len(p) != 3:
                return None
        digits = ''.join(parts)
    else:
        if not body.isdigit() or not body.isascii():
            return None
        digits = body
    if not digits:
        return None
    val = 0
    for ch in digits:
        val = val * 10 + (ord(ch) - 48)
    return sign * val