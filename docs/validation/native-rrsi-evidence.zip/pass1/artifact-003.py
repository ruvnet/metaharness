def solve(data):
    if not isinstance(data, str):
        return 0
    s = data.strip()
    if not s:
        return 0
    if not s.isascii():
        return 0
    if not s.isupper():
        return 0
    allowed = set(['I', 'V', 'X', 'L', 'C', 'D', 'M'])
    for ch in s:
        if ch not in allowed:
            return 0
    values = {'I': 1, 'V': 5, 'X': 10, 'L': 50, 'C': 100, 'D': 500, 'M': 1000}
    total = 0
    prev = 0
    for ch in reversed(s):
        val = values[ch]
        if val < prev:
            total -= val
        else:
            total += val
        prev = val
    if total < 1 or total > 3999:
        return 0
    # Verify canonical form by converting back
    def to_roman(n):
        if n <= 0 or n > 3999:
            return ''
        table = [
            (1000, 'M'), (900, 'CM'), (500, 'D'), (400, 'CD'),
            (100, 'C'), (90, 'XC'), (50, 'L'), (40, 'XL'),
            (10, 'X'), (9, 'IX'), (5, 'V'), (4, 'IV'), (1, 'I')
        ]
        res = []
        for val, sym in table:
            while n >= val:
                res.append(sym)
                n -= val
        return ''.join(res)
    if to_roman(total) != s:
        return 0
    return total