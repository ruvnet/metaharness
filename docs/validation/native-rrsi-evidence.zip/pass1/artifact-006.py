def solve(data):
    if not isinstance(data, str):
        return None
    if data == '':
        return ['']
    fields = []
    i = 0
    n = len(data)
    while i < n:
        if data[i] == '"':
            i += 1
            buf = []
            while i < n:
                if data[i] == '"':
                    if i + 1 < n and data[i + 1] == '"':
                        buf.append('"')
                        i += 2
                    else:
                        i += 1
                        break
                else:
                    buf.append(data[i])
                    i += 1
            if i >= n:
                fields.append(''.join(buf))
                break
            if data[i] != ',':
                return None
            fields.append(''.join(buf))
            i += 1
        else:
            start = i
            while i < n and data[i] != ',':
                if data[i] == '"':
                    return None
                i += 1
            fields.append(data[start:i])
            if i < n:
                i += 1
    return fields