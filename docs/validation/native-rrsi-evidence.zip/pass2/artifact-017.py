def solve(data):
    total = 0
    for item in data:
        if not isinstance(item, str):
            continue
        s = item.strip()
        if not s:
            continue
        if ':' not in s:
            continue
        parts = s.split(':')
        if len(parts) != 2:
            continue
        m_part = parts[0]
        ss_part = parts[1]
        if len(m_part) < 1:
            continue
        if not m_part.isascii():
            continue
        if not m_part.isdigit():
            continue
        if len(ss_part) != 2:
            continue
        if not ss_part.isascii():
            continue
        if not ss_part.isdigit():
            continue
        ss_val = int(ss_part)
        if ss_val < 0 or ss_val > 59:
            continue
        m_val = int(m_part)
        total += m_val * 60 + ss_val
    return total