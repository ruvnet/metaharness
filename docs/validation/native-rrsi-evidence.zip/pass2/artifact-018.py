def solve(data):
    if not isinstance(data, str):
        return 0
    if len(data) == 0:
        return 0
    if not data.isascii():
        return 0
    for ch in data:
        if ch not in 'IVXLCDM':
            return 0
    values = {'I': 1, 'V': 5, 'X': 10, 'L': 50, 'C': 100, 'D': 500, 'M': 1000}
    total = 0
    prev = 0
    for ch in data:
        val = values[ch]
        if val < prev:
            total -= val
        else:
            total += val
        prev = val
    if total < 1 or total > 3999:
        return 0
    if data.count('I') > 3:
        return 0
    if data.count('X') > 3:
        return 0
    if data.count('C') > 3:
        return 0
    if data.count('M') > 3:
        return 0
    if 'VV' in data or 'LL' in data or 'DD' in data:
        return 0
    if 'IIII' in data or 'XXXX' in data or 'CCCC' in data:
        return 0
    if 'IV' in data or 'IX' in data or 'XL' in data or 'XC' in data or 'CD' in data or 'CM' in data:
        pass
    else:
        if 'I' in data and 'V' in data:
            idx_i = data.index('I')
            idx_v = data.index('V')
            if idx_i + 1 != idx_v:
                return 0
        if 'I' in data and 'X' in data:
            idx_i = data.index('I')
            idx_x = data.index('X')
            if idx_i + 1 != idx_x:
                return 0
        if 'X' in data and 'L' in data:
            idx_x = data.index('X')
            idx_l = data.index('L')
            if idx_x + 1 != idx_l:
                return 0
        if 'X' in data and 'C' in data:
            idx_x = data.index('X')
            idx_c = data.index('C')
            if idx_x + 1 != idx_c:
                return 0
        if 'C' in data and 'D' in data:
            idx_c = data.index('C')
            idx_d = data.index('D')
            if idx_c + 1 != idx_d:
                return 0
        if 'C' in data and 'M' in data:
            idx_c = data.index('C')
            idx_m = data.index('M')
            if idx_c + 1 != idx_m:
                return 0
    return total