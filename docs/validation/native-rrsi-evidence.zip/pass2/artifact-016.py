def solve(data):
    total = 0
    for item in data:
        if not isinstance(item, str):
            continue
        s = item.strip()
        if not s:
            continue
        if not s.isascii():
            continue
        parts = s.split(':')
        if len(parts) != 2:
            continue
        m_part = parts[0]
        ss_part = parts[1]
        if len(m_part) < 1:
            continue
        if not m_part.isdigit():
            continue
        if len(ss_part) != 2:
            continue
        if not ss_part.isdigit():
            continue
        m_val = 0
        for ch in m_part:
            m_val = m_val * 10 + (ord(ch) - 48)
        ss_val = (ord(ss_part[0]) - 48) * 10 + (ord(ss_part[1]) - 48)
        if ss_val > 59:
            continue
        total += m_val * 60 + ss_val
    return total