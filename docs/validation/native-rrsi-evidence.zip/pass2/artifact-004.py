def solve(data):
    if not isinstance(data, str):
        return 0
    s = data.strip()
    if not s:
        return 0
    if not s.isascii():
        return 0
    if not s.isupper():
        return 0
    valid_chars = set(['I', 'V', 'X', 'L', 'C', 'D', 'M'])
    for ch in s:
        if ch not in valid_chars:
            return 0
    values = {'I': 1, 'V': 5, 'X': 10, 'L': 50, 'C': 100, 'D': 500, 'M': 1000}
    total = 0
    prev = 0
    for ch in reversed(s):
        val = values[ch]
        if val < prev:
            total -= val
        else:
            total += val
        prev = val
    if total < 1 or total > 3999:
        return 0
    # Verify canonical form by converting back
    def to_roman(n):
        if n <= 0 or n > 3999:
            return ''
        vals = [1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1]
        syms = ['M', 'CM', 'D', 'CD', 'C', 'XC', 'L', 'XL', 'X', 'IX', 'V', 'IV', 'I']
        res = []
        for i in range(len(vals)):
            while n >= vals[i]:
                res.append(syms[i])
                n -= vals[i]
        return ''.join(res)
    if to_roman(total) != s:
        return 0
    return total