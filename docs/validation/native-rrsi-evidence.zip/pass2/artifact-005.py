def solve(data):
    if not isinstance(data, str):
        return None
    if data == '':
        return ['']
    fields = []
    i = 0
    n = len(data)
    while True:
        if i < n and data[i] == '"':
            i += 1
            buf = []
            closed = False
            while i < n:
                c = data[i]
                if c == '"':
                    if i + 1 < n and data[i + 1] == '"':
                        buf.append('"')
                        i += 2
                    else:
                        closed = True
                        i += 1
                        break
                else:
                    buf.append(c)
                    i += 1
            if not closed:
                return None
            if i < n and data[i] != ',':
                return None
            fields.append(''.join(buf))
            if i < n:
                i += 1
                if i == n:
                    fields.append('')
                    break
            else:
                break
        else:
            start = i
            while i < n and data[i] != ',':
                if data[i] == '"':
                    return None
                i += 1
            fields.append(data[start:i])
            if i < n:
                i += 1
                if i == n:
                    fields.append('')
                    break
            else:
                break
    return fields